/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectlibrarymanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author Adriaan
 */
class Book {
    private String author;
    private String title;
    private String ISBN;
    private int availableUnits;
    private static List<Book> allBooks = new ArrayList<>();
    private LocalDate dueDate;
    
    public Book( String title,String author, String ISBN, int availableUnits) {
        this.author = author;
        this.title = title;
        this.ISBN = ISBN;
        this.availableUnits = availableUnits;
    }
    
    // Getters and setters
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public int getAvalibleUnits() {
        return availableUnits;
    }

    public void setAvalibleUnits(int availableUnits) {
        this.availableUnits = availableUnits;
    }
    
    public static String addBook(String title, String author, String ISBN, int availableUnits) {
        // Check if the ISBN already exists in the book list
        for (Book book : allBooks) {
            if (book.getISBN().equals(ISBN)) {
                return "Book with ISBN " + ISBN + " already exists.";
            }
        }

        // Create a new Book object
        Book newBook = new Book(title, author, ISBN, availableUnits);

        // Add the new book to the list of all books
        allBooks.add(newBook);

        // Update the file containing the list of books
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("books.txt", true))) {
            // Write the details of the new book to the file
            writer.write(String.format("%s;%s;%s;%d\n", title, author, ISBN, availableUnits));
            return "Book added successfully.";
        } catch (IOException e) {
            System.out.println("An error occurred while adding the book.");
            e.printStackTrace();
            return "Error occurred while adding the book.";
        }
    }
    
    public static Book findBookByISBN(String ISBN) {
        for (Book book : allBooks) {
            if (book.getISBN().equalsIgnoreCase(ISBN)) {
                return book;
            }
        }
        return null;
    }

    public static String removeBook(String ISBN) {
        // Find the book with the given ISBN
        Book bookToRemove = findBookByISBN(ISBN);

        if (bookToRemove != null) {
            // Remove the book from the list of all books
            allBooks.remove(bookToRemove);

            // Rewrite the books.txt file excluding the removed book
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("books.txt"))) {
                for (Book book : allBooks) {
                    writer.write(String.format("%s;%s;%s;%d\n", 
                    book.getTitle(), 
                    book.getAuthor(), 
                    book.getISBN(), 
                    book.getAvalibleUnits()));
                }
                return "Book removed successfully.";
            } catch (IOException e) {
                System.out.println("An error occurred while removing the book.");
                e.printStackTrace();
                return "Error occurred while removing the book.";
            }
        } else {
            return "Book with ISBN '" + ISBN + "' not found.";
        }
    }

    public static String editBook(String title, String author, Integer availableUnits, String ISBN) {
        // Find the book with the given ISBN
        Book bookToEdit = findBookByISBN(ISBN);

        if (bookToEdit != null) {
            // Update the book details if the new values are not null
            if (title != null) {
                for (int i = 0; i < allBooks.size(); i++) {
                    if (allBooks.get(i).getISBN().equals(ISBN)) {
                        allBooks.get(i).setTitle(title);
                    }
                }
                // Update the title of the bookToEdit as well (just in case it's the same book)
                bookToEdit.setTitle(title);
                    }
            if (author != null) {
                for (int i = 0; i < allBooks.size(); i++) {
                    if (allBooks.get(i).getISBN().equals(ISBN)) {
                        allBooks.get(i).setAuthor(author);
                    }
                }
                bookToEdit.setAuthor(author);
            }
            if (availableUnits != null) {
                for (int i = 0; i < allBooks.size(); i++) {
                    if (allBooks.get(i).getISBN().equals(ISBN)) {
                        allBooks.get(i).setAvalibleUnits(availableUnits);
                    }
                }
                bookToEdit.setAvalibleUnits(availableUnits);
            }

            // Rewrite the books.txt file with the updated book details
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("books.txt"))) {
                for (Book book : allBooks) {
                    writer.write(String.format("%s;%s;%s;%d\n", 
                    book.getTitle(), 
                    book.getAuthor(), 
                    book.getISBN(), 
                    book.getAvalibleUnits()));
                }
                return "Book details updated successfully.";
            } catch (IOException e) {
                System.out.println("An error occurred while updating the book details.");
                e.printStackTrace();
                return "Error occurred while updating the book details.";
            }
        } else {
            return "Book with ISBN '" + ISBN + "' not found.";
        }
    }


    public static String searchBook(String title, String author) {
        // Create a report to store the details of matching books
        StringBuilder report = new StringBuilder();
        report.append("Search Results:\n");
        report.append(String.format("%-20s %-20s %-20s %-20s\n", "Title", "Author", "ISBN", "Available Units"));

        // Check if either title or author is provided for search
        if (title == null && author == null) {
            return "Please provide either title or author for search.";
        }

        // Flag to indicate if any matching books were found
        boolean found = false;

        // Loop through all books to find matches
        for (Book book : allBooks) {
            // Check if the book matches the search criteria
            if ((title == null || book.getTitle().toLowerCase().contains(title.toLowerCase())) &&
                (author == null || book.getAuthor().toLowerCase().contains(author.toLowerCase()))) {
                // Append book details to the report
                report.append(String.format("%-20s %-20s %-20s %-20s\n",
                book.getTitle(),
                book.getAuthor(),
                book.getISBN(),
                book.getAvalibleUnits()));
                found = true;
            }
        }
        // If no matching books were found, append a message
        if (!found) {
            report.append("No books found matching the search criteria.");
        }

        // Return the search results
        return report.toString();
    }

    public static String displayBooks() {
        StringBuilder bookDetails = new StringBuilder();
        bookDetails.append("All Books:\n");
        bookDetails.append(String.format("%-20s %-20s %-20s %-20s\n", "Title", "Author", "ISBN", "Available Units"));

        // Iterate over all books and append their details to the string
        for (Book book : allBooks) {
            bookDetails.append(String.format("%-20s %-20s %-20s %-20s\n",
                book.getTitle(),
                book.getAuthor(),
                book.getISBN(),
                book.getAvalibleUnits()));
        }

        // Return the string containing all book details
        return bookDetails.toString();
    }

    public static boolean rentBook(String ISBN) {
        // Find the book with the given ISBN
        Book bookToRent = findBookByISBN(ISBN);
        
        if (bookToRent != null) {
            // Check if there are available units
            if (bookToRent.getAvalibleUnits() > 0) {
                // Decrement the available units
                bookToRent.setAvalibleUnits(bookToRent.getAvalibleUnits() - 1);

                // Rewrite the books.txt file with the updated book details
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("books.txt"))) {
                    for (Book book : allBooks) {
                        writer.write(String.format("%s;%s;%s;%d\n", 
                        book.getTitle(), 
                        book.getAuthor(), 
                        book.getISBN(), 
                        book.getAvalibleUnits()));
                    }
                    return true; // Book rented successfully
                } catch (IOException e) {
                    System.out.println("An error occurred while updating the book details.");
                    e.printStackTrace();
                    return false; // Error occurred while updating the book details
                }
            } else {
                return false; // No available units
            }
        } else {
            return false; // Book not found
        }
    }

    public static String viewRentedBooks(List<String> rentedBooks, List<String> dueDates) {
        // Create a StringBuilder to store the report
        StringBuilder report = new StringBuilder();
        report.append("Rented Books Report:\n");
        report.append(String.format("%-40s %-30s %-30s %-30s\n", "Title", "Author", "ISBN", "Due Date"));

        // Check if the rentedBooks list is null or empty
        if (rentedBooks == null || rentedBooks.isEmpty()) {
            report.append("No rented books found.");
        } else {
            // Flag to indicate if any matching books were found
            boolean found = false;

            // Loop through all books in the book list
            for (Book book : allBooks) {
                // Check if the book's ISBN is in the rentedBooks list
                if (rentedBooks.contains(book.getISBN())) {
                    int index = rentedBooks.indexOf(book.getISBN()); // Get the index of the book's ISBN in the rentedBooks list
                    String dueDate = (index != -1 && index < dueDates.size()) ? dueDates.get(index) : "N/A"; // Get the corresponding due date from the dueDates list
                    // Append book details to the report (including due date)
                    report.append(String.format("%-40s %-30s %-30s %-30s\n",
                            book.getTitle(),
                            book.getAuthor(),
                            book.getISBN(),
                            dueDate));
                    found = true;
                }
            }

            // If no matching books were found, append a message
            if (!found) {
                report.append("No rented books found matching the provided list.");
            }
        }

        // Return the generated report
        return report.toString();
    }

    public static String viewDueDates(List<String> rentedBooks, List<String> dueDates, List<Double> fines) {
        // Create a StringBuilder to store the report
        StringBuilder report = new StringBuilder();

        // Check if the rentedBooks list is null or empty
        if (rentedBooks == null || rentedBooks.isEmpty()) {
            report.append("No rented books found.");
        } else {
            // Loop through all books in the rentedBooks list
            for (String ISBN : rentedBooks) {
                // Find the index of the book's ISBN in the rentedBooks list
                int index = rentedBooks.indexOf(ISBN);

                // Check if the index is valid and within the dueDates and fines lists' size
                if (index >= 0 && index < dueDates.size() && index < fines.size()) {
                    String dueDate = dueDates.get(index); // Get the corresponding due date from the dueDates list
                    double fineAmount = fines.get(index); // Get the corresponding fine amount from the fines list
                    String fineAmountFormatted = formatCurrency(fineAmount); // Format fine amount as currency

                    // Find the book with the given ISBN
                    Book book = findBookByISBN(ISBN);

                    if (book != null) {
                        // Append book details to the report (including due date and fine amount)
                        report.append(String.format("%-40s %-30s %-30s %-30s %-30s\n",
                                book.getTitle(),
                                book.getAuthor(),
                                book.getISBN(),
                                dueDate,
                                fineAmountFormatted));
                    } else {
                        // Book not found
                        report.append("Book with ISBN '").append(ISBN).append("' not found.\n");
                    }
                } else {
                    // Index out of bounds for dueDates or fines lists
                    report.append("Index out of bounds for dueDates or fines lists.\n");
                }
            }
        }
        // Return the generated report
        return report.toString();
    }


    // Method to format currency
    private static String formatCurrency(double amount) {
        // Format fine amount as currency using Locale.US
        NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.ENGLISH);
        return formatter.format(amount);
    }

    public static boolean returnBook(String ISBN) {
        // Find the book with the given ISBN
        Book bookToReturn = findBookByISBN(ISBN);

        if (bookToReturn != null) {
            // Increment the availability of the book
            bookToReturn.setAvalibleUnits(bookToReturn.getAvalibleUnits() + 1);

            // Rewrite the books.txt file with the updated book details
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("books.txt"))) {
                for (Book book : allBooks) {
                    writer.write(String.format("%s;%s;%s;%d\n", 
                    book.getTitle(), 
                    book.getAuthor(), 
                    book.getISBN(), 
                    book.getAvalibleUnits()));
                }
                System.out.println("Book returned successfully.");
                return true;
            } catch (IOException e) {
                System.out.println("An error occurred while returning the book.");
                e.printStackTrace();
                return false;
            }
        } else {
            System.out.println("Book with ISBN '" + ISBN + "' not found.");
            return false;
        }
    }


    
    public static List<Book> loadBooks() {
        String bookFile = "Books.txt";
        List<Book> books = new ArrayList<>();

        File tmpDir = new File(bookFile);
        boolean exists = tmpDir.exists();

        if (!exists) {
            try {
                FileOutputStream fos = new FileOutputStream(bookFile);
                fos.flush();
                fos.close();
                return books;
            } catch (IOException e) {
                System.out.println("An error occurred");
                e.printStackTrace();
            }
        }

        allBooks.clear();
        try (FileInputStream fis = new FileInputStream("books.txt");
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 4) { // Ensure there are correct parts
                    int availableUnits = Integer.parseInt(parts[3]);
                    Book book = new Book(parts[0], parts[1], parts[2], availableUnits);
                    books.add(book);
                } else {
                    System.out.println("Invalid format for book details in line: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while loading books.");
            e.printStackTrace();
        }
        allBooks.addAll(books);
        return books;
    }

    }