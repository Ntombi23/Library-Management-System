/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectlibrarymanagementsystem;

/**
 *
 * @author NtombiNgcwangu
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.time.LocalDate;

/**
 *
 * @author Adriaan
 */
class Member {
    private String name;
    private String email;
    private List<String> books;
    private String password;
    private Boolean Admin; 
    private static List<Member> allMembers = new ArrayList<>();
    private List<LocalDate> dueDates = new ArrayList<>();

     public Member(String name, String email, List<String> rentedBooks, List<LocalDate> dueDates, String password, Boolean admin) {
        this.name = name;
        this.email = email;
        this.books = rentedBooks;
        this.dueDates = dueDates;
        this.password = password;
        this.Admin = admin;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getBooks() {
        return books;
    }
    

    public void setBooks(List<String> books) {
        this.books = books;
    }
    
    public String getPassword(){
        return password;
    }
    
    public List<LocalDate> getDueDates() {
        return dueDates;
    }
    
    public String getRentedBooksAsString() {
        StringBuilder builder = new StringBuilder();
        for (String book : books) {
            builder.append(book).append(",");
        }
        // Remove the trailing comma if there are rented books
        if (builder.length() > 0) {
            builder.deleteCharAt(builder.length() - 1);
        }
        return builder.toString();
    }
    
    public static List<Member> loadMembers() {
        List<Member> members = new ArrayList<>();

        String memberFile = "Members.txt";
        String initialAdmin = "Adriaan;adriaancoetzee2004@gmail.com;;;AdminA01;y\n";
        File tmpDir = new File(memberFile);
        boolean exists = tmpDir.exists();

        if(!exists) {
            try {
                FileOutputStream fos = new FileOutputStream(memberFile);
                fos.write(initialAdmin.getBytes());
                fos.flush();
                fos.close();
                return members;
            } catch (IOException e){
                System.out.println("An error occurred");
                e.printStackTrace();
            }
        }

        try (FileInputStream fis = new FileInputStream("members.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader reader = new BufferedReader(isr)) {

           String line;
           while ((line = reader.readLine()) != null) {
               String[] parts = line.split(";");
               
               if (parts.length >= 6) { // Ensure there are correct parts
                   List<String> rentedBooks = new ArrayList<>();
                   for (int i = 0; i <6 ;i++){
                    System.out.println(parts[i]);
                   }
                   List<LocalDate> dueDates = new ArrayList<>(); // Initialize due dates list
                   boolean admin = false;
                   // Check and trim each part to handle empty fields
                   for (int i = 0; i < parts.length; i++) {
                       parts[i] = parts[i].trim();
                   }
                   if (!parts[2].isEmpty()) { // Check if there are rented books
                       rentedBooks = new ArrayList<>(Arrays.asList(parts[2].split(",")));
                   }
                   // Initialize due dates corresponding to rented books if not empty
               if (!parts[3].isEmpty()) {
                    String[] dueDateStrings = parts[3].split(",");
                    for (String dateString : dueDateStrings) {
                        if (!dateString.isEmpty()) { // Skip empty strings
                            dueDates.add(LocalDate.parse(dateString));
                        }
                    }
                }
                   if ("y".equals(parts[5])) {
                       admin = true;
                   }
                   members.add(new Member(parts[0], parts[1], rentedBooks, dueDates, parts[4], admin));
               } else {
                   System.out.println("Invalid format for member details in line: " + line);
               }
           }
       } catch (IOException e) {
           System.out.println("An error occurred while loading members.");
           e.printStackTrace();
       }


        allMembers = members;
        return members;
    }

    
    public static Boolean isAdmin(String email, String password) {
        

        for (Member member : allMembers) {
            if (member.Admin) {//If the member is a admin
                if (member.getEmail().equals(email) && member.password.equals(password)) {
                    return true; // Admin found with matching email and password
                }
            }
        }
        return false; // No admin found with matching email and password
    }
    
    public static Member isMember(String email, String password) {
        for (Member member : allMembers) {
            if (member.getEmail().equals(email) && member.getPassword().equals(password)) {
                return member; // Return the member if email and password match
            }
        }
        return null; // Return null if no member with matching email and password is found
    }
    
    public String getDueDatesAsString() {
        StringBuilder builder = new StringBuilder();
        for (LocalDate date : dueDates) {
            builder.append(date).append(",");
        }
        if (builder.length() > 0) {
            builder.deleteCharAt(builder.length() - 1);
        }
        return builder.toString();
    }

    private static void writeMemberToFile(Member member) {
        // Update the file containing the list of members
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt", true))) {
            // Construct the string to write to the file
            StringBuilder memberDetails = new StringBuilder();
            memberDetails.append(member.getName()).append(";")
                         .append(member.getEmail()).append(";");

            
            // Append password and admin status
            memberDetails.append(";;").append(member.getPassword()).append(";n\n");

            // Write the constructed member details to the file
            writer.write(memberDetails.toString());
        } catch (IOException e) {
            System.out.println("An error occurred while writing member details to the file.");
            e.printStackTrace();
        }
    }
    
    public static boolean addMember(String name, String email, String password) {
        // Check if the email already exists in the members list
        for (Member member : allMembers) {
            if (member.getEmail().equals(email)) {
                return false; // Email already exists, member cannot be added
            }
        }

        // Create a new Member object
        Member newMember = new Member(name, email, new ArrayList<>(), new ArrayList<>(), password, false);

        // Add the new member to the list
        allMembers.add(newMember);

        // Write the new member's details to the file
        writeMemberToFile(newMember);

        return true; // Member successfully added
    }


    
    public static String generateMemberReport() {
        StringBuilder report = new StringBuilder();

        report.append("Member Report:\n");
        report.append(String.format("%-20s %-30s %-20s\n", "Name", "Email", "Books Rented (with Due Dates)"));

        for (Member member : allMembers) {
            List<String> rentedBooks = member.getBooks();
            List<LocalDate> dueDates = member.getDueDates();
            StringBuilder rentedBooksInfo = new StringBuilder();
            for (int i = 0; i < rentedBooks.size(); i++) {
                String book = rentedBooks.get(i);
                LocalDate dueDate = dueDates.get(i);
                rentedBooksInfo.append(book);
                if (dueDate != null) {
                    rentedBooksInfo.append(" (Due Date: ").append(dueDate).append(")");
                }
                if (i < rentedBooks.size() - 1) {
                    rentedBooksInfo.append(", ");
                }
            }
            report.append(String.format("%-20s %-30s %-20s\n", 
                member.getName(), 
                member.getEmail(),                             
                rentedBooksInfo.toString()                            
            ));
        }

        return report.toString();
    }

     
    public static String removeMember(String email) {
        // Find the member with the given email address
        Member memberToRemove = null;
        for (Member member : allMembers) {
            if (member.getEmail().equalsIgnoreCase(email)) {
                memberToRemove = member;
                break;
            }
        }

        if (memberToRemove != null) {
            // Check if the member to be removed is not an admin
            if (!memberToRemove.isAdmin(memberToRemove.getEmail(), memberToRemove.getPassword())) {
                // Remove the member from the list of all members
                allMembers.remove(memberToRemove);

                // Rewrite the members.txt file excluding the removed member
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt"))) {
                    for (Member member : allMembers) {
                        StringBuilder memberDetails = new StringBuilder();
                        memberDetails.append(member.getName()).append(";")
                                     .append(member.getEmail()).append(";");

                        List<String> rentedBooks = member.getBooks();
                        List<LocalDate> dueDates = member.getDueDates();
                        for (int i = 0; i < rentedBooks.size(); i++) {
                            memberDetails.append(rentedBooks.get(i));
                            // If there are due dates for the book, append it
                            if (i < dueDates.size() && dueDates.get(i) != null) {
                                memberDetails.append(";").append(dueDates.get(i));
                            }
                            if (i < rentedBooks.size() - 1) {
                                memberDetails.append(",");
                            }
                        }
                        memberDetails.append(";;").append(member.getPassword()).append(";");
                        memberDetails.append(member.isAdmin(member.getEmail(), member.getPassword()) ? "y" : "n");
                        writer.write(memberDetails.toString() + "\n");
                    }
                    return "Member removed successfully.";
                } catch (IOException e) {
                    System.out.println("An error occurred while removing the member.");
                    e.printStackTrace();
                    return "Error occurred while removing the member.";
                }
            } else {
                return "Admin member cannot be removed.";
            }
        } else {
            return "Member with email '" + email + "' not found.";
        }
    }


    public static String addBook(Member currentMember, String ISBN, LocalDate dueDate) {
    // Find the member in the list
    Member memberToAddBook = null;
    for (Member member : allMembers) {
        if (member.getEmail().equalsIgnoreCase(currentMember.getEmail())) {
            memberToAddBook = member;
            break;
        }
    }

    if (memberToAddBook != null) {
        // Add the ISBN to the rented books list of the member
        memberToAddBook.getBooks().add(ISBN);
        // Add the due date to the due dates list
        memberToAddBook.getDueDates().add(dueDate);

        // Update the file containing the list of members
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt"))) {
            for (Member member : allMembers) {
                StringBuilder memberDetails = new StringBuilder();
                memberDetails.append(member.getName()).append(";")
                             .append(member.getEmail()).append(";");

                // Concatenate ISBNs
                List<String> rentedBooks = member.getBooks();
                StringBuilder ISBNList = new StringBuilder();
                for (int i = 0; i < rentedBooks.size(); i++) {
                    ISBNList.append(rentedBooks.get(i));
                    if (i < rentedBooks.size() - 1) {
                        ISBNList.append(",");
                    }
                }
                memberDetails.append(ISBNList).append(";");

                // Concatenate due dates
                List<LocalDate> dueDates = member.getDueDates();
                StringBuilder dueDateList = new StringBuilder();
                for (int i = 0; i < dueDates.size(); i++) {
                    dueDateList.append(dueDates.get(i));
                    if (i < dueDates.size() - 1) {
                        dueDateList.append(",");
                    }
                }
                memberDetails.append(dueDateList).append(";");

                memberDetails.append(member.getPassword()).append(";");
                memberDetails.append(member.isAdmin(member.getEmail(), member.getPassword()) ? "y" : "n");
                writer.write(memberDetails.toString() + "\n");
            }
            return "Book added to the member's rented list successfully.";
        } catch (IOException e) {
            System.out.println("An error occurred while adding a book to the member's rented list.");
            e.printStackTrace();
            return "Error occurred while adding a book to the member's rented list.";
        }
    } else {
        return "Member not found.";
    }
}



    public static List<String> viewRentedBooks(Member currentMember) {
        // Find the member in the list
        Member memberToViewRentedBooks = null;
        for (Member member : allMembers) {
            if (member.getEmail().equalsIgnoreCase(currentMember.getEmail())) {
                memberToViewRentedBooks = member;
                break;
            }
        }

        List<String> rentedBooksAndDueDates = new ArrayList<>();

        if (memberToViewRentedBooks != null) {
            List<String> rentedBooks = memberToViewRentedBooks.getBooks();
            List<LocalDate> dueDates = memberToViewRentedBooks.getDueDates();

            // Combine rented books and due dates into a single string for each book
            for (int i = 0; i < rentedBooks.size(); i++) {
                String bookWithDueDate = rentedBooks.get(i);
                if (i < dueDates.size()) {
                    LocalDate dueDate = dueDates.get(i);
                    bookWithDueDate += ";" + dueDate.toString() ;
                }
                rentedBooksAndDueDates.add(bookWithDueDate);
            }

            return rentedBooksAndDueDates;
        } else {
            // Return null if member is not found
            return null;
        }
    }


    public static Boolean returnBook(String ISBN, Member currentMember) {
        // Check if the currentMember is not null
        if (currentMember != null) {
            // Check if the currentMember has any rented books
            if (currentMember.getBooks() != null) {
                // Search for the ISBN in the currentMember's list of rented books
                List<String> rentedBooks = currentMember.getBooks();
                int index = rentedBooks.indexOf(ISBN);
                if (index != -1) {
                    // Remove the ISBN and its corresponding due date from the currentMember's lists
                    rentedBooks.remove(index);
                    currentMember.getDueDates().remove(index);

                    // Update the file containing the list of members
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt"))) {
                        for (Member member : allMembers) {
                            StringBuilder memberDetails = new StringBuilder();
                            memberDetails.append(member.getName()).append(";")
                                         .append(member.getEmail()).append(";");

                            List<String> books = member.getBooks();
                            List<LocalDate> dueDates = member.getDueDates();
                            for (int i = 0; i < books.size(); i++) {
                                memberDetails.append(books.get(i));
                                // If there are due dates for the book, append it
                                if (i < dueDates.size() && dueDates.get(i) != null) {
                                    memberDetails.append(";").append(dueDates.get(i));
                                }
                                if (i < books.size() - 1) {
                                    memberDetails.append(",");
                                }
                            }
                            memberDetails.append(";;").append(member.getPassword()).append(";");
                            memberDetails.append(member.isAdmin(member.getEmail(), member.getPassword()) ? "y" : "n");
                            writer.write(memberDetails.toString() + "\n");
                        }
                        System.out.println("Book returned successfully.");
                        return true;
                    } catch (IOException e) {
                        System.out.println("An error occurred while returning the book.");
                        e.printStackTrace();
                        return false;
                    }
                } else {
                    System.out.println("Member has not rented the book with ISBN '" + ISBN + "'.");
                    return false;
                }
            } else {
                System.out.println("Member has not rented any books.");
                return false;
            }
        } else {
            System.out.println("Invalid member provided.");
            return false;
        }
    }

    public static Double calculateFine(Long daysOverdue){
        if (daysOverdue > 0){
            Double fine = (double)(daysOverdue * 20);
            return fine;
        } else
            return (double)0;
    }
}
