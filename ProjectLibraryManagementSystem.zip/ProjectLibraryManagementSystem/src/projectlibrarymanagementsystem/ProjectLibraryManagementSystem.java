/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projectlibrarymanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author NtombiNgcwangu
 */
public class ProjectLibraryManagementSystem {

    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



    static Member CurrentMember;
    
    public static void main(String[] args) {
        List<Book> books = Book.loadBooks();
        List<Member> members = Member.loadMembers();
        List<NotificationThread> allNotifications = new ArrayList<>();
        
        Scanner input = new Scanner(System.in);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            // Call the clearNotificationsFile method before exiting
            signOut(allNotifications);
        }));
        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Member Menu");
            System.out.println("2. Admin Menu");
            System.out.println("3. Exit");
            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
            }
            
            switch (choice) {
                case 1:
                    memberMenu(books, input, allNotifications);
                    break;
                case 2:
                    adminMenu(members,books, input);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    input.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 3.");
            }
        }
    }   
    
    public static void adminMenu(List<Member> members, List<Book> books, Scanner input) {
        while(true){
            System.out.println("Admin Menu:");
            System.out.println("1. Sign in");
            System.out.println("2. Back");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    signInAdmin(members, input);
                    if(CurrentMember.isAdmin(CurrentMember.getEmail(), CurrentMember.getPassword())){
                        adminOperations(members, books, input);
                    }
                    break;
                case 2:
                    System.out.println("Going back...");
                    CurrentMember = null;
                    return; // Return to the main menu
                default:
                    System.out.println("Invalid choice. Please enter either 1 or 2.");
            }
        }
    }
    
    public static void adminOperations(List<Member> members, List<Book> books, Scanner input){
        while (true){
            System.out.println("Admin Operations : "); 
            System.out.println("1. Search for Members");
            System.out.println("2. View All Members");
            System.out.println("3. Remove member");
            System.out.println("4. Book management");
            System.out.println("5. Back");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                break;
            }

            switch (choice) {
                    case 1:
                        searchMemberByName(members, input);
                        break;
                    case 2:
                        System.out.println(Member.generateMemberReport());
                        break;
                    case 3:
                        System.out.println("Enter the email of the user : ");
                        String email = input.nextLine();
                        System.out.println(Member.removeMember(email));
                        break;
                    case 4:
                        bookManagement(books, input);
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter either 1 to 4.");
                }
        }
    }
    
    
    public static void bookManagement(List<Book> books,Scanner input){
        while(true){
            System.out.println("Book Management:");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Edit Book");
            System.out.println("4. Search for Book");
            System.out.println("5. Display All Books");
            System.out.println("6. Back to Menu");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
                
            }

            switch(choice)
            {
                case 1:
                    addBook(books, input);
                    break;
                case 2:
                    removeBook(books, input);
                    break;
                case 3:
                    editBook(books, input);
                    System.out.println("Program needs to restart to apply changes...");
                    break;
                case 4:
                    searchBook(books, input);
                    break;
                case 5:
                    System.out.println(Book.displayBooks());
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter only 1 to 6.");
            }
        }
    }
    
    public static void restartApplication()
    {
      try{
      final String javaBin = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
      final File currentJar = new File(ProjectLibraryManagementSystem.class.getProtectionDomain().getCodeSource().getLocation().toURI());

      /* is it a jar file? */
      if(!currentJar.getName().endsWith(".jar"))
        return;

      /* Build command: java -jar application.jar */
      final ArrayList<String> command = new ArrayList<String>();
      command.add(javaBin);
      command.add("-jar");
      command.add(currentJar.getPath());

      final ProcessBuilder builder = new ProcessBuilder(command);
      builder.start();
      System.exit(0);
      } catch (Exception e){
          System.out.println(e);
      }          
    }
    
    public static void addBook(List<Book> books, Scanner input) {
        System.out.println("Enter the book details:");
        System.out.println("Title:");
        String title = input.nextLine();
        System.out.println("Author:");
        String author = input.nextLine();

        String ISBN;
        while (true) {
            System.out.println("ISBN:");
            ISBN = input.nextLine();

            // Check if ISBN is in the correct format (e.g., 10 or 13 digits)
            if (isValidISBN(ISBN)) {
                break;
            } else {
                System.out.println("Invalid ISBN format. ISBN should be 10 or 13 digits.");
            }
        }

        int availableUnits;
        while (true) {
            System.out.println("Available Units:");
            try {
                availableUnits = input.nextInt();
                if (availableUnits >= 0) {
                    break;
                } else {
                    System.out.println("Invalid input. Available units cannot be negative.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer for available units.");
                input.nextLine(); // Clear the input buffer
            }
        }
        System.out.println(Book.addBook(title, author, ISBN, availableUnits));
    }

    public static boolean isValidISBN(String ISBN) {
        // ISBN should be either 10 or 13 digits
        return ISBN.matches("\\d{10}|\\d{13}");
    }
    
    public static void removeBook(List<Book> books, Scanner input){
        System.out.println("Enter ISBN of the book : ");
        String ISBN = input.nextLine();
        
        System.out.println(Book.removeBook(ISBN));
    }

    public static void editBook(List<Book> books, Scanner input) {
        System.out.println("Enter ISBN of book to edit : ");
        String ISBN = input.nextLine();

        Book editedBook = Book.findBookByISBN(ISBN);

        if (editedBook != null) {
            System.out.println("Enter the new details for the book:");
            System.out.println("Title (leave blank to keep the same): ");
            String newTitle = input.nextLine();
            System.out.println("Author (leave blank to keep the same): ");
            String newAuthor = input.nextLine();
            System.out.println("Available Units (enter -1 to keep the same): ");
            int newAvailableUnits = input.nextInt();
            input.nextLine(); // Consume newline

            String result = Book.editBook(newTitle.isEmpty() ? null : newTitle, 
            newAuthor.isEmpty() ? null : newAuthor, 
            newAvailableUnits == -1 ? null : newAvailableUnits, 
            ISBN);

            System.out.println(result);
        } else {
            System.out.println("Book with ISBN '" + ISBN + "' not found.");
        }
    }

    public static void searchBook(List<Book> books, Scanner input) {
        System.out.println("Search by Title or Author?");
        System.out.println("1. Title");
        System.out.println("2. Author");
        System.out.print("Enter your choice: ");
        int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                return;
            }

        String searchTerm = null;
        if (choice == 1) {
            System.out.print("Enter the title: ");
            searchTerm = input.nextLine();
        } else if (choice == 2) {
            System.out.print("Enter the author: ");
            searchTerm = input.nextLine();
        } else {
            System.out.println("Invalid choice.");
            return;
        }

        // Call the searchBook method and display the results
        System.out.println(Book.searchBook(choice == 1 ? searchTerm : null, choice == 2 ? searchTerm : null));
    }

    
    public static void memberMenu(List<Book> books, Scanner input, List<NotificationThread> allNotifications){
        while (true){
            System.out.println("Member Menu:");
            System.out.println("1. Sign In");
            System.out.println("2. Sign Up");
            System.out.println("3. Back");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
            }

            switch (choice){
                case 1: 
                    memberSignIn(books, input, allNotifications);
                    if(CurrentMember!=null){
                        memberOperations(books, input,allNotifications);
                    }
                    break;
                case 2:
                    memberSignUp(books, input);
                    if(CurrentMember!=null){
                        memberOperations(books, input,allNotifications);
                    }
                    break;
                case 3:
                    System.out.println("Going back...");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter only 1 to 3.");
            }
        }
        
    }
    
    public static void memberOperations(List<Book> books,Scanner input,List<NotificationThread> allNotifications){
        while(true){
            System.out.println("Choose an option :");
            System.out.println("1. Rent a Book");
            System.out.println("2. Return a Book");
            System.out.println("3. View Rented Books");
            System.out.println("4. View due dates and fines");
            System.out.println("5. Notifications");
            System.out.println("6. Sign out");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
            }

            switch (choice){
                case 1:
                    rentBook(books,input,allNotifications);
                    break;
                case 2:
                    returnBook(input,allNotifications);
                    break;
                case 3:
                    viewRentedBooks(input);
                    break;
                case 4:
                    viewDueDates(input);
                    break;
                case 5:
                    for (int i = 1; i <= allNotifications.size(); i++) {
                        String filePath = "Notification" + i + ".txt";
                        File tempFile = new File(filePath);
                        if (tempFile.exists()){
                            System.out.println(NotificationManager.loadNotificationsFromFile(filePath));
                        }
                    }
                    break;
                case 6:
                    CurrentMember = null;
                    signOut(allNotifications);
                    return;
                default:
                    System.out.println("Invalid choice. Please enter number 1 to 6.");
            }
        }
    }
    
    public static void signOut(List<NotificationThread> allNotifications) {
        // Stop all notification threads
        int Counter = 0;
        for (NotificationThread thread : allNotifications) {
            thread.stopThread();
        }
        // Clear all notification files
         for (int i = 1; i <= allNotifications.size(); i++) {
            String filePath = "Notification" + i + ".txt";
            File tempFile = new File(filePath);
            if (tempFile.exists()){
                NotificationManager.clearNotificationsFile(filePath);
            }
        }
    }
    
    public static void viewDueDates(Scanner input){
        List<String> rentedBooksAndDueDates = Member.viewRentedBooks(CurrentMember);
        List<String> rentedBooks = new ArrayList<>();
        List<String> stringDueDates = new ArrayList<>();
        List<LocalDate> dueDates = new ArrayList<>();
        Double fine = (double)0;
        List<Double> fines = new ArrayList<>();
        
        System.out.println("Rented Books Report:\n");
        System.out.println(String.format("%-40s %-30s %-30s %-30s %-30s\n", "Title", "Author", "ISBN", "Due Date", "Fine Amount"));
        for (String bookWithDueDate : rentedBooksAndDueDates) {
            String[] parts = bookWithDueDate.split(";");
            rentedBooks.add(parts[0]); 
            stringDueDates.add(parts[1]);
            
            LocalDate dueDate = LocalDate.parse(parts[1]); 
            dueDates.add(dueDate);
            
            LocalDate today = LocalDate.now();
            long daysDifference = today.toEpochDay() - dueDate.toEpochDay(); 
            
            fine = Member.calculateFine(daysDifference);
            fines.add(fine);
        }
       System.out.println(Book.viewDueDates(rentedBooks, stringDueDates, fines));
    }
    
    public static void rentBook(List<Book> books, Scanner input, List<NotificationThread> allNotifications){
        while(true){
            System.out.println("Rent a Book:");
            System.out.println("1. View All Books");
            System.out.println("2. Search Books");
            System.out.println("3. Enter ISBN of the book to rent");
            System.out.println("4. Back to Member Menu");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine(); // Consume newline
            } catch (Exception e){
                System.out.println("Please enter a valid number...");
                input.nextLine();
                continue;
            }

            switch (choice){
                case 1:
                    System.out.println(Book.displayBooks());
                    break;
                case 2:
                    searchBook(books, input);
                    break;
                case 3:
                    System.out.println("Enter ISBN : ");
                    String ISBN = input.nextLine();
                    if (Book.rentBook(ISBN)){
                        System.out.println("Book rented successfully");
                        LocalDate dueDate = LocalDate.now().plusDays(7);
                        System.out.println(Member.addBook(CurrentMember, ISBN, dueDate));
                        Book currentBook = Book.findBookByISBN(ISBN);
                        if (currentBook != null){
                            if (currentBook.getAvalibleUnits()>0){
                                List<String> booksToUpdate = CurrentMember.getBooks();
                                booksToUpdate.add(ISBN);
                                CurrentMember.setBooks(booksToUpdate);
                            }
                        }

                        // Start a notification thread for the rented book
                        String bookISBN = ISBN;
                        LocalDate today = LocalDate.now();
                        long daysDifference = today.toEpochDay() - dueDate.toEpochDay();
                        double fineAmount = Member.calculateFine(daysDifference);
                        int identifier = allNotifications.size() + 1; // Incrementing the identifier
                        NotificationThread notificationThread = new NotificationThread(bookISBN, dueDate, fineAmount, identifier);
                        notificationThread.start(); // Start the notification thread
                        allNotifications.add(notificationThread); 
                    } else{
                        System.out.println("Book unavailable...");
                    }
                    LocalDate dueDate = LocalDate.now().plusDays(7);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter either 1 to 4.");
            }
        }
    }
    
    public static void returnBook(Scanner input, List<NotificationThread> allNotifications){
        List<String> rentedBooksAndDueDates = Member.viewRentedBooks(CurrentMember);
        List<String> rentedBooks = new ArrayList<>();
        List<String> dueDates = new ArrayList<>();
                
        for (String bookWithDueDate : rentedBooksAndDueDates) {
            String[] parts = bookWithDueDate.split(";");
            rentedBooks.add(parts[0]); 
            dueDates.add(parts[1]);
        }
        
        System.out.println(Book.viewRentedBooks(rentedBooks,dueDates));
        System.out.println("Enter ISBN of the book you want to return :");
        String ISBN = input.nextLine();
        if(Book.returnBook(ISBN)&& Member.returnBook(ISBN, CurrentMember)){
            Book currentBook = Book.findBookByISBN(ISBN);
            if (currentBook != null){
               if (currentBook.getAvalibleUnits()>0){
                  List<String> booksToUpdate = CurrentMember.getBooks();
                  booksToUpdate.remove(ISBN);
                  CurrentMember.setBooks(booksToUpdate);
                }
            }
            for (NotificationThread notificationThread : allNotifications) {
                if (notificationThread.getBookISBN().equals(ISBN)) {
                    // Stop the notification thread
                    notificationThread.stopThread();
                    // Remove the book's notification from the file
                    String notificationFilePath = "Notification" + notificationThread.getIdentifier() + ".txt";
                    NotificationManager.deleteNotificationFromFile("Book with ISBN " + ISBN + " is overdue!", notificationFilePath);
                    // Remove the notification thread from the list
                    allNotifications.remove(notificationThread);
                    break; // Exit the loop once the notification thread is found
                }
            }
        }
        
    }
    
    public static void viewRentedBooks(Scanner input){
        List<String> rentedBooksAndDueDates = Member.viewRentedBooks(CurrentMember);
        List<String> rentedBooks = new ArrayList<>();
        List<String> dueDates = new ArrayList<>();
                
        for (String bookWithDueDate : rentedBooksAndDueDates) {
            String[] parts = bookWithDueDate.split(";");
            rentedBooks.add(parts[0]); 
            dueDates.add(parts[1]);
           
        }

        // Call the Book.viewRentedBooks method with only the rented books (ISBNs)
        System.out.println(Book.viewRentedBooks(rentedBooks,dueDates));
    }

    
    
    public static void signInAdmin(List<Member> members, Scanner input) {
        while (true) {
            System.out.println("Enter Admin Email: ");
            String adminEmail = input.nextLine();
            System.out.println("Enter Admin Password: ");
            String adminPassw = input.nextLine();
            
            Member tempMember = Member.isMember(adminEmail,adminPassw);
            if (Member.isAdmin(adminEmail, adminPassw)) {
                System.out.println("Admin signed in successfully!");
                CurrentMember = tempMember;
                return; // Exit signInAdmin method
            } else {
                System.out.println("Wrong email or password. Please try again...");
            }
        }
    }
    
    public static void memberSignIn(List<Book> books, Scanner input,List<NotificationThread> allNotifications){
        while(true){
            System.out.println("Enter Email: ");
            String email = input.nextLine();
            System.out.println("Enter Password: ");
            String passw = input.nextLine();
            
            Member tempMember = Member.isMember(email,passw);
            if (tempMember!=null){
                CurrentMember = tempMember;
                List<String> rentedBooksAndDueDates = Member.viewRentedBooks(CurrentMember);
                List<String> rentedBooks = new ArrayList<>();
                List<String> dueDates = new ArrayList<>();
                for (String bookWithDueDate : rentedBooksAndDueDates) {
                    String[] parts = bookWithDueDate.split(";");
                    rentedBooks.add(parts[0]); 
                    dueDates.add(parts[1]);               
                }
                // Start a notification thread for each book
                for (int i = 0; i < rentedBooks.size(); i++) {
                    String bookISBN = rentedBooks.get(i);
                    LocalDate dueDate = LocalDate.parse(dueDates.get(i)); 
                    LocalDate today = LocalDate.now();
                    long daysDifference = today.toEpochDay() - dueDate.toEpochDay(); 
                    double fineAmount = Member.calculateFine(daysDifference); 
                    int identifier = i + 1; // Identifier for the notification thread
                    NotificationThread notificationThread;
                    notificationThread = new NotificationThread(bookISBN, dueDate, fineAmount, identifier);
                    notificationThread.start(); // Start the notification thread
                    allNotifications.add(notificationThread); // Add the notification thread to the list
                }
                return;
            }
            else{
                System.out.println("Wrong email or password...");
            }
        }
    }
    
    public static void memberSignUp(List<Book> books, Scanner input){
        System.out.println("Enter name : ");
        String name = input.nextLine();
        String email;
        String password;
        while (true){
            System.out.println("Enter Email : ");
            email = input.nextLine();
            if (!isValidEmail(email)) {
                System.out.println("Invalid email format!");
            } else{
                break;
            }
        }
        
        while(true){
            System.out.println("Enter Password : ");
            password = input.nextLine();
            if (!isValidPassword(password)) {
                System.out.println("Invalid password format!");
            } else{
                break;
            }
        }
        
        if(Member.addMember(name, email, password)){
        Member tempMember = new Member(name, email, new ArrayList<>(),new ArrayList<>(), password, false);
        CurrentMember = tempMember;
        System.out.println("Member signed up successfully");
        } else {
            System.out.println("Email already exists...");
        }
    }
    
      public static boolean isValidEmail(String email) {
        // Regular expression for email validation
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    
    public static boolean isValidPassword(String password) {
        // Regular expression for password validation
        String passwordRegex = "^(?=.*[a-zA-Z0-9!@#$%^&*()-_=+\\\\|\\[{\\]};:'\\\",<.>/?]).{8,}$";
        Pattern pattern = Pattern.compile(passwordRegex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }
    
    public static void searchMemberByName(List<Member> members, Scanner input) {
        System.out.println("Enter the name to search for:");
        String searchName = input.nextLine().toLowerCase(); // Convert search name to lowercase for case-insensitive comparison

        boolean found = false;
        for (Member member : members) {
            if (member.getName().toLowerCase().contains(searchName)) { // Case-insensitive contains check
                System.out.println("Member found:");
                System.out.println("Name: " + member.getName());
                System.out.println("Email: " + member.getEmail());
                System.out.println("Books Rented: " + member.getRentedBooksAsString());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No member found with the specified name.");
        }
    }

    public static void removeMember(Scanner input){
        System.out.println("Enter the email of the user : ");
        String email = input.nextLine();
        
        System.out.println(Member.removeMember(email));
    }

    public static class NotificationThread extends Thread {
        private String bookISBN;
        private LocalDate dueDate;
        private double fineAmount;
        private int identifier;
        private int notificationAmount;

        public NotificationThread(String bookISBN, LocalDate dueDate, double fineAmount,int identifier) {
            this.bookISBN = bookISBN;
            this.dueDate = dueDate;
            this.fineAmount = fineAmount;
            this.identifier = identifier;
            notificationAmount = 0;
        }
        
        public String getBookISBN() {
            return this.bookISBN;
        }

        public int getIdentifier() {
            return this.identifier;
        }

        public void setFine(double fineAmount){
            this.fineAmount = fineAmount;
        }
        
        @Override
        public void run() {
            while (true) {
                // Check if the due date is reached
                if (LocalDate.now().isAfter(dueDate)) {
                    LocalDate today = LocalDate.now();
                    long daysDifference = today.toEpochDay() - dueDate.toEpochDay(); 

                    setFine(Member.calculateFine(daysDifference));
                    
                    Book currentBook = Book.findBookByISBN(bookISBN);
                    String notificationFilePath = "Notification" + identifier + ".txt";
                    NotificationManager.saveNotificationToFile("Book : Author " + 
                    currentBook.getAuthor() +"\nTitle : " +currentBook.getTitle()+
                    "\nISBN : "+bookISBN + 
                    "\nIs overdue!\n" + "Fine Amount: " + fineAmount,notificationFilePath);
                    notificationAmount++;
                } else if (notificationAmount<1){
                    Book currentBook = Book.findBookByISBN(bookISBN);
                    String notificationFilePath = "Notification" + identifier + ".txt";
                    NotificationManager.saveNotificationToFile("Book : Author " + 
                    currentBook.getAuthor() +"\nTitle : " +currentBook.getTitle()+
                    "\nISBN : "+bookISBN +  
                    "\n Is due on "+ dueDate + "\nFine Amount: " + fineAmount,notificationFilePath);
                    notificationAmount++;
                }

                // Sleep for some time before checking again
                try {
                    // Sleep for 5 minutes 
                    Thread.sleep(300000);
                } catch (InterruptedException e) {
                    // Thread interrupted, exit the loop
                    return;
                }
            }
        }

        // Method to stop the thread when the book is returned
        public void stopThread() {
            interrupt();
        }
    }
    
    public static class NotificationManager {
        public static void saveNotificationToFile(String notification, String filePath) {
            try (FileWriter writer = new FileWriter(filePath, true)) {
                writer.write(notification + System.lineSeparator());
                System.out.println("You have new notifications!!");
            } catch (IOException e) {
                System.err.println("Error saving notification to file: " + e.getMessage());
            }
        }

        public static String loadNotificationsFromFile(String filePath) {
            StringBuilder notifications = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    notifications.append(line).append(System.lineSeparator());
                }
            } catch (IOException e) {
                System.err.println("Error loading notifications from file: " + e.getMessage());
            }
            return notifications.toString();
        }

        public static void clearNotificationsFile(String filePath) {
            try (FileWriter writer = new FileWriter(filePath, false)) {
                // Clear the file by writing nothing
                writer.write("");
            } catch (IOException e) {
                System.err.println("Error clearing notifications file: " + e.getMessage());
            }
        }

        public static void deleteNotificationFromFile(String notification, String filePath) {
            List<String> notifications = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.equals(notification)) {
                        notifications.add(line);
                    }
                }
            } catch (IOException e) {
                System.err.println("Error deleting notification from file: " + e.getMessage());
                return;
            }

            // Write back the filtered notifications to the file
            try (FileWriter writer = new FileWriter(filePath, false)) {
                for (String line : notifications) {
                    writer.write(line + System.lineSeparator());
                }
            } catch (IOException e) {
                System.err.println("Error writing filtered notifications to file: " + e.getMessage());
            }
        }
    }
}

    